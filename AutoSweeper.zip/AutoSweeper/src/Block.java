import java.util.Random;

public class Block {

    private Boolean bomb;
    private int surr = 0;

    public Block(){
        bomb = false;
    }

    public Block(Boolean bomb){
        bomb = bomb;
    }

    public Boolean getBomb(){
        return bomb;
    }

    public void setSurr(int surr){
        surr = surr;
    }

    public int getSurr(){
        return surr;
    }

    public void setBomb(){
        bomb = true;
    }

    public void setBomb(boolean flag){
        bomb = flag;
    }

    public void upSurr(){
        surr++;
    }

    public static Block[][] makeBoard(int dim, int y, int x){

        int num1;
        int num2;
        Block[][] blocks = new Block[dim][dim];
        Random r = new Random();

        for(int i = 0; i < dim; i++){
            for(int j = 0; j < dim; j++){
                blocks[i][j] = new Block();
            }
        }

        for(int bombCap = (dim*dim)/4; bombCap > 0; bombCap--){
            num1 = r.nextInt(dim);
            num2 = r.nextInt(dim);
            if(Math.abs(y - num1) == 1 || Math.abs(x - num2) == 1 || (y == num1 && x == num2)){
                bombCap++;
                continue;
            }
            if(!blocks[num1][num2].getBomb()){
                blocks[num1][num2].setBomb();
                bombNum(blocks, num1, num2);
            }
            else{
                bombCap++;
            }
        }



        return blocks;
    }

    private static void bombNum(Block[][] blocks, int i, int j){
        try {
            blocks[i + 1][j].upSurr();
        }
        catch (ArrayIndexOutOfBoundsException e){}
        try {
            blocks[i + 1][j + 1].upSurr();
        }
        catch (ArrayIndexOutOfBoundsException e){}
        try {
            blocks[i + 1][j - 1].upSurr();
        }
        catch (ArrayIndexOutOfBoundsException e){}
        try {
            blocks[i - 1][j].upSurr();
        }
        catch (ArrayIndexOutOfBoundsException e){}
        try {
            blocks[i - 1][j + 1].upSurr();
        }
        catch (ArrayIndexOutOfBoundsException e){}
        try {
            blocks[i - 1][j - 1].upSurr();
        }
        catch (ArrayIndexOutOfBoundsException e){}
        try {
            blocks[i][j + 1].upSurr();
        }
        catch (ArrayIndexOutOfBoundsException e){}
        try {
            blocks[i][j - 1].upSurr();
        }
        catch (ArrayIndexOutOfBoundsException e){}
    }

    public static void main(String[] args){

    }
}
