public class Driver {
    public static void main(String[] args) {
        try {
            new GUI();
        }
        catch(ArrayIndexOutOfBoundsException e){}
    }

}
